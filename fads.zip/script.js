var click = addEventListener("click", doClick);

function doClick() {
	
}