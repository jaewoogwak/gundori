var btn = document.getElementsByClassName("submitBtn");
btn.addEventListener("onclick", saveValue);
var userName;
var startDate;
var group;
var endDate;


function saveValue() {
	userName = document.getElementsByClassName("enterName");
	alert(userName.value);
}




